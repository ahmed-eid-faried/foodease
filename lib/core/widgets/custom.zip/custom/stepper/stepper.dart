import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/imports/export_path_packages.dart';

import '../text_custom/text_custom.dart';

class StepperWidget extends StatefulWidget {
  const StepperWidget({super.key});

  @override
  State<StepperWidget> createState() => _StepperWidgetState();
}

class _StepperWidgetState extends State<StepperWidget> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 342.w,
      decoration: ShapeDecoration(
        color: AppColor.white2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextCustom(
              text: 'History',
              style: AppFontStyle.black14w600smcp(),
            ),
          ),
          Stepper(
            currentStep: _index,
            physics: const NeverScrollableScrollPhysics(),
            onStepTapped: (int index) {
              setState(() {
                _index = index;
              });
            },
            controlsBuilder: (BuildContext context, ControlsDetails details) {
              return Container();
            },
            connectorColor: MaterialStateProperty.all(AppColor.black),
            steps: <Step>[
              Step(
                title: TextCustom(
                  text: 'Package have been received',
                  style: AppFontStyle.black14w500(),
                ),
                content: Container(
                  alignment: Alignment.centerLeft,
                  child: const TextCustom(text: 'Content for Step 1'),
                ),
                isActive: true,
              ),
              const Step(
                title: TextCustom(text: 'Step 2 title'),
                content: TextCustom(text: 'Content for Step 2'),
              ),
            ],
            stepIconBuilder: (stepIndex, stepState) => Container(
              width: 10.sp,
              height: 10.sp,
              decoration: const ShapeDecoration(
                color: Colors.black,
                shape: CircleBorder(
                  side: BorderSide(width: 1, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryOfOrderWidget extends StatelessWidget {
  const HistoryOfOrderWidget({
    super.key,
    this.activeOrderStyle = false,
    this.returnOrderStyle = false,
    this.color = AppColor.white2,
  });

  final bool activeOrderStyle;
  final bool returnOrderStyle;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 342.w,
      padding: EdgeInsets.all(AppPadding.p8.r),
      decoration: ShapeDecoration(
        color: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextCustom(
            text: LocaleKeys.history,
            style: AppFontStyle.black14w600smcp(),
          ),
          SizedBox(height: AppSize.s16.h),
          ListView.builder(
            physics: const BouncingScrollPhysics(),
            shrinkWrap: true,
            itemCount: 4,
            itemBuilder: (context, index) => HistoryItemTrackerOrderWidget(
              index: index,
              activeOrderStyle: activeOrderStyle,
              returnOrderStyle: returnOrderStyle,
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryItemTrackerOrderWidget extends StatelessWidget {
  const HistoryItemTrackerOrderWidget({
    super.key,
    required this.index,
    this.activeOrderStyle = false,
    this.returnOrderStyle = false,
    this.trackOrderStyle = false,
  });

  final int index;
  final bool activeOrderStyle;
  final bool trackOrderStyle;
  final bool returnOrderStyle;

  @override
  Widget build(BuildContext context) {
    return (index == 2 && trackOrderStyle)
        ? buildTrackOrderRowBeforeLast(context)
        : (index != 3)
            ? buildNormalRow()
            : returnOrderStyle
                ? buildRefundProcessedWidget()
                : (activeOrderStyle
                    ? buildActiveOrderRow(context)
                    : (trackOrderStyle
                        ? buildIntrackOrderRow()
                        : buildInactiveOrderRow()));
  }

  Widget buildNormalRow() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildDateTimeColumn(),
        SizedBox(width: AppSize.s11.w),
        buildStatusColumn(),
        SizedBox(width: AppSize.s11.w),
        TextCustom(
          text: LocaleKeys.packageHaveBeenReceived,
          style: AppFontStyle.black14w500(),
        ),
      ],
    );
  }

  Widget buildDateTimeColumn() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 20.w,
          child: TextCustom(
            text: '${LocaleKeys.june.tr()} 26',
            style: AppFontStyle.black12w500(),
          ),
        ),
        SizedBox(height: AppSize.s4.h),
        TextCustom(
          text: '11:00',
          style: AppFontStyle.grey11w400(),
        ),
      ],
    );
  }

  Widget buildStatusColumn({
    bool buildStatusIndicatorState = true,
    Color color = Colors.black,
    double height = AppSize.s58,
  }) {
    return Column(
      children: [
        if (buildStatusIndicatorState) buildStatusIndicator(),
        returnOrderStyle && index == 3 - 1
            ? const TextCustom(text: "")
            : Container(
                alignment: Alignment.center,
                width: AppSize.s1.r,
                height: AppSize.s58.r,
                color: color,
              ),
      ],
    );
  }

  Widget buildStatusIndicator() {
    return Container(
      alignment: Alignment.center,
      width: AppSize.s10.r,
      height: AppSize.s10.r,
      decoration: const ShapeDecoration(
        color: AppColor.black,
        shape: CircleBorder(
          side: BorderSide(width: AppSize.s1, color: AppColor.white),
        ),
      ),
    );
  }

  Widget buildRefundProcessedWidget() {
    return Padding(
      padding: EdgeInsets.all(AppPadding.p22.r),
      child: Center(
        child: TextCustom(
          text: LocaleKeys.refundProcessed,
          style: AppFontStyle.grey14w500(),
        ),
      ),
    );
  }

  Widget buildActiveOrderRow(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildDateTimeColumn(),
        SizedBox(width: AppSize.s11.w),
        buildStatusIndicator(),
        SizedBox(width: AppSize.s11.w),
        TextCustom(
          text: LocaleKeys.arrivedToDestination,
          style: AppFontStyle.black14w500(),
        ),
        const Spacer(),
        buildScanButton(context),
      ],
    );
  }

  Widget buildTrackOrderRowBeforeLast(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildDateTimeColumn(),
        SizedBox(width: AppSize.s11.w),
        buildStatusColumn(color: AppColor.grey, height: 10),
        SizedBox(width: AppSize.s11.w),
        TextCustom(
          text: LocaleKeys.arrivedToDestination,
          style: AppFontStyle.black14w500(),
        ),
      ],
    );
  }

  Widget buildScanButton(BuildContext context) {
    return InkWell(
      // onTap: () => Go.navigator(context, Routes.qrCodeView),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextCustom(
            text: LocaleKeys.scan,
            style: AppFontStyle.red12w400underline(),
          ),
          SizedBox(width: 4.w),
          const SvgPictureCustom(
            AppSvg.qrScan,
            width: AppSize.s20,
            height: AppSize.s20,
          ),
        ],
      ),
    );
  }

  Widget buildInactiveOrderRow() {
    return Row(
      children: [
        SizedBox(width: AppSize.s70.w),
        buildStatusColumn(),
        SizedBox(width: AppSize.s11.w),
        TextCustom(
          text: LocaleKeys.arrivedToDestination,
          style: AppFontStyle.grey14w500(),
        ),
      ],
    );
  }

  Widget buildIntrackOrderRow() {
    return Row(
      children: [
        SizedBox(width: AppSize.s48.w),
        buildStatusColumn(
          buildStatusIndicatorState: false,
          color: AppColor.grey,
        ),
        SizedBox(width: AppSize.s11.w),
        TextCustom(
          text: LocaleKeys.arrivedToDestination,
          style: AppFontStyle.grey14w500(),
        ),
      ],
    );
  }
}
