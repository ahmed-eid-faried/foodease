import 'package:flutter/material.dart';
import 'package:vendors/core/utils/values_manager.dart';

import '../../themes/app_theme.dart';

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: AppPadding.p20),
      child: Center(
        child: SizedBox(
          height: AppSize.s30,
          width: AppSize.s30,
          child: CircularProgressIndicator(
            color: secondaryColor,
          ),
        ),
      ),
    );
  }
}
