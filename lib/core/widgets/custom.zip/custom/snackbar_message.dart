import 'package:vendors/core/widgets/text_custom/text_custom.dart';

import '../../../../core copy/imports/export_path.dart';

class SnackBarMessage {
  void showSuccessSnackBar(
      {required String message, required BuildContext context}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: TextCustom(
          text: message,
          style: const TextStyle(color: AppColor.white),
        ),
        backgroundColor: Colors.green,
      ),
    );
  }

  void showErrorSnackBar(
      {required String message, required BuildContext context}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: TextCustom(
          text: message,
          style: const TextStyle(color: AppColor.white),
        ),
        backgroundColor: Colors.redAccent,
      ),
    );
  }
}
