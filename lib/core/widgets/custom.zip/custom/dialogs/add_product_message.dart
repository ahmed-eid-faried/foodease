import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/widgets/text_custom/text_custom.dart';

class AddProductMessageFail extends StatelessWidget {
  const AddProductMessageFail({super.key});
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.zero,
      content: addProductMessage(
        desc: 'There’s Something \nWent Wrong With Your Product',
        fristTitleOfButton: 'Try Again',
        secondTitleOfButton: 'Back To Home Page',
        iconInner: AppSvg.errorX,
        iconOuter: AppSvg.errorMessage,
        fristOnTapButton: () {
          // Go.navigator(context, Routes.addproduct),
          // refresh functions
          Navigator.pop(context);
        },
        secondOnTapButton: () => Go.navigatorAndRemove(context, Routes.home),
      ),
    );
  }
}

class AddProductMessageSuccess extends StatelessWidget {
  const AddProductMessageSuccess({super.key});
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.zero,
      content: addProductMessage(
        desc: 'Your Adding product request Was Approved Successfully',
        fristTitleOfButton: "Add More",
        secondTitleOfButton: 'Back To Home',
        iconInner: AppSvg.ticker,
        iconOuter: AppSvg.report,
        fristOnTapButton: () {
          // Go.navigator(context, Routes.addproduct),
          // refresh functions
          Navigator.pop(context);
        },
        secondOnTapButton: () => Go.navigatorAndRemove(context, Routes.home),
      ),
    );
  }
}

Widget addProductMessage(
    {void Function()? fristOnTapButton,
    void Function()? secondOnTapButton,
    required String iconInner,
    required String iconOuter,
    required String desc,
    required String fristTitleOfButton,
    required String secondTitleOfButton}) {
  return Container(
    padding: EdgeInsets.symmetric(
        horizontal: AppPadding.p32.w, vertical: AppPadding.p32.h),
    decoration: shapeDecoration(
      color: AppColor.white,
      shape: roundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: AppSize.s58.w,
            height: AppSize.s58.h,
            child: Stack(
              alignment: AlignmentDirectional.topStart,
              children: [
                Center(
                  child: SvgPictureCustom(
                    iconInner,
                    width: AppSize.s24,
                    height: AppSize.s24,
                  ),
                ),
                Center(
                  child: SvgPictureCustom(iconOuter,
                      width: AppSize.s58, height: AppSize.s58),
                ),
              ],
            ),
          ),
          SizedBox(height: AppSize.s8.h),
          TextCustom(
              text: desc,
              textAlign: TextAlign.center,
              style: AppFontStyle.black12w400()),
          SizedBox(height: AppSize.s32.h),
          CustomButton(
            label: fristTitleOfButton,
            function: fristOnTapButton,
          ),
          SizedBox(height: AppSize.s8.h),
          CustomButton(
            label: secondTitleOfButton,
            color: AppColor.white,
            flipColor: true,
            function: secondOnTapButton,
            borderColor: AppColor.black,
          ),
        ]),
  );
}
