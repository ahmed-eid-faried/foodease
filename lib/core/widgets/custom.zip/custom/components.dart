import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:foodease/core/utill/colors.dart';
import 'package:foodease/core/utill/values_manager.dart';

Future<bool?> showToast(
    {required String message, Color color = AppColor.green}) {
  return Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_SHORT,
    gravity: ToastGravity.BOTTOM,
    timeInSecForIosWeb: 1,
    backgroundColor: color,
    textColor: Colors.white,
    fontSize: AppSize.s16,
  );
}
