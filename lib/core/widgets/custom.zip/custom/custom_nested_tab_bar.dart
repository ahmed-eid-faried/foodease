import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:foodease/core/widgets/custom/custom_scaffold.dart';
import 'package:foodease/core/widgets/custom/text_custom/text_custom.dart';
 
class CustomNestedTabBar extends StatelessWidget {
  const CustomNestedTabBar({
    super.key,
    required this.appBar,
    required this.tabs,
    required this.children,
    this.initialIndex = 0,
    this.bottomNavigationBar,
    this.extendBody = true,
  });
  final PreferredSizeWidget appBar;
  final List<Widget> tabs;
  final List<Widget> children;
  final int initialIndex;
  final Widget? bottomNavigationBar;
  final bool extendBody;
  @override
  Widget build(BuildContext context) {
    return tabs.length == children.length
        ? DefaultTabController(
            initialIndex: initialIndex,
            length: tabs.length,
            child: CustomScaffold(
              appBar: appBar,
              extendBody: extendBody,
              bottomNavigationBar: bottomNavigationBar,
              body: NestedTabBar(
                tabs: tabs,
                children: children,
              ),
            ),
          )
        : const TextCustom(text: "tabs.length != children.length");
  }
}

class NestedTabBar extends StatefulWidget {
  const NestedTabBar({super.key, required this.tabs, required this.children});
  final List<Widget> tabs;
  final List<Widget> children;

  @override
  State<NestedTabBar> createState() => _NestedTabBarState();
}

class _NestedTabBarState extends State<NestedTabBar>
    with TickerProviderStateMixin {
  late final TabController _tabController;
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: widget.tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        TabBar.secondary(
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          indicatorColor: AppColor.black,
          dividerColor: Colors.transparent,
          labelStyle: AppFontStyle.black12w400smcp(),
          unselectedLabelStyle: AppFontStyle.grey12w400smcp(),
          overlayColor: const MaterialStatePropertyAll(
              Color.fromARGB(255, 230, 230, 230)),
          controller: _tabController,
          tabs: widget.tabs,
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: widget.children,
          ),
        ),
      ],
    );
  }
}
