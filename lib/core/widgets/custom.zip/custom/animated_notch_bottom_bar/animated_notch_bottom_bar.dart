library animated_notch_bottom_bar;

export 'package:vendors/core/widgets/animated_notch_bottom_bar/src/controller/notch_bottom_bar_controller.dart';
export 'package:vendors/core/widgets/animated_notch_bottom_bar/src/models/bottom_bar_item_model.dart';
export 'package:vendors/core/widgets/animated_notch_bottom_bar/src/notch_bottom_bar.dart';
