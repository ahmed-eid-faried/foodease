import 'dart:io';

import 'package:vendors/core/imports/export_path.dart';
import 'package:video_player/video_player.dart';

class CustomVideoWidget extends StatefulWidget {
  const CustomVideoWidget(
      {super.key,
      required this.url,
      this.aspectRatio,
      this.file,
      this.fileState = false,
      this.startPlayState = true,
      this.button = true,
      this.buttonFun = true,
      this.sizeButton = 30,
      this.backState = false});
  final String url;
  final File? file;
  final bool fileState;
  final bool startPlayState;
  final bool button;
  final bool buttonFun;
  final double? aspectRatio;
  final double sizeButton;
  final bool backState;

  @override
  State<CustomVideoWidget> createState() => _CustomVideoWidgetState();
}

class _CustomVideoWidgetState extends State<CustomVideoWidget> {
  late VideoPlayerController _controller;
  bool playState = false;

  @override
  void initState() {
    super.initState();
    debugPrint(
        " CustomVideoWidget file:- ${widget.fileState && widget.file != null}");
    _controller = widget.fileState && widget.file != null
        ? VideoPlayerController.file(widget.file!)
        : VideoPlayerController.networkUrl(Uri.parse(widget.url));
    // 'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4'
    _controller.initialize().then((_) {
      // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
      _controller.setLooping(true);
      if (widget.startPlayState) {
        _controller.play();
        playState = true;
      }
      _controller.addListener(() {});
      debugPrint("===============================================");
      debugPrint("playvideo:-${widget.url}");
      debugPrint("===============================================");
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Center(
          child: _controller.value.isInitialized
              ? AspectRatio(
                  aspectRatio:
                      widget.aspectRatio ?? _controller.value.aspectRatio,
                  child: VideoPlayer(_controller),
                )
              : CachedNetworkImageCustom(
                  url: widget.url,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: (AppSize.s100 * 5.58).h),
        ),
        Visibility(
          visible: widget.button,
          child: Center(
            child: IconButton(
                onPressed: () {
                  if (widget.buttonFun) {
                    setState(() {
                      if (playState) {
                        _controller.pause();
                        playState = false;
                      } else {
                        _controller.play();
                        playState = true;
                      }
                    });
                  }
                },
                icon: Icon(
                  playState
                      ? Icons.pause_circle_filled_outlined
                      : Icons.play_circle_fill_outlined,
                  color: AppColor.white,
                  size: widget.sizeButton,
                )),
          ),
        ),
        Visibility(
          visible: widget.backState,
          child: Align(
            alignment: Alignment.topLeft,
            child: IconButton(
                onPressed: () {
                  Go.pop(context);
                },
                icon: Icon(
                  Icons.arrow_back_ios_rounded,
                  color: AppColor.white,
                  size: widget.sizeButton.landscapeFontSp(),
                )),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    debugPrint("==================dispose=============================");
    super.dispose();
    _controller.dispose();
  }
}
