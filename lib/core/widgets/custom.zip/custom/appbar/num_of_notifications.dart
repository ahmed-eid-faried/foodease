import 'package:vendors/core/widgets/text_custom/text_custom.dart';

import '../../../../../core copy/imports/export_path.dart';

class NumOfNotifications extends StatelessWidget {
  const NumOfNotifications({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 0,
      right: 0,
      child: Container(
        width: AppSize.s16,
        height: AppSize.s16,
        padding: const EdgeInsets.symmetric(
            horizontal: AppPadding.p4, vertical: AppPadding.p1),
        decoration: shapeDecoration(
          color: AppColor.red,
          shape: roundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s100),
          ),
        ),
        child: TextCustom(
          text: '2',
          style: AppFontStyle.white11w400(),
        ),
      ),
    );
  }
}
