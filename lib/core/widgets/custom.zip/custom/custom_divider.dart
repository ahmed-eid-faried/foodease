 
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:foodease/core/utill/colors.dart';
import 'package:foodease/core/utill/values_manager.dart';

class CustomDivider extends StatelessWidget {
  final double? height;
  final double? thickness;
  final double? indent;
  final double? endIndent;
  final Color? color;
  const CustomDivider({
    super.key,
    this.height = AppSize.s1,
    this.thickness = AppSize.s1,
    this.indent,
    this.endIndent,
    this.color = AppColor.white2,
  });

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: height,
      thickness: thickness,
      indent: indent,
      endIndent: endIndent,
      color: color,
    );
  }
}
