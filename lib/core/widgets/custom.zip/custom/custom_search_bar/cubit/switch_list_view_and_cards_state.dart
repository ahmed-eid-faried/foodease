// ignore_for_file: public_member_api_docs, sort_constructors_first
part of 'switch_list_view_and_cards_cubit.dart';

@immutable
abstract class SwitchListViewAndCardsState extends Equatable {
  const SwitchListViewAndCardsState();
  @override
  List<Object> get props => [];
}

class IntialState extends SwitchListViewAndCardsState {
  final bool state;
  const IntialState({this.state = true});
  @override
  List<Object> get props => [state];
}

class ChangeState extends SwitchListViewAndCardsState {
  final bool state;
  const ChangeState({required this.state});
  @override
  List<Object> get props => [state];
}
