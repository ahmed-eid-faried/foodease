import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vendors/core/imports/export_path.dart';

part 'switch_list_view_and_cards_state.dart';

class SwitchListViewAndCardsCubit extends Cubit<SwitchListViewAndCardsState> {
  SwitchListViewAndCardsCubit() : super(const IntialState());
  bool cardState = true;

  switchFun({bool reset = false}) {
    //debugPrint("======================inner===========================");
    reset
        ? emit(const ChangeState(state: true))
        : {cardState = !cardState, emit(ChangeState(state: cardState))};
  }
}
