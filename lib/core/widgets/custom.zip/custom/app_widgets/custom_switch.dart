import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/widgets/app_widgets/flutter_advanced_switch.dart';

class CustomSwitch extends StatelessWidget {
  const CustomSwitch({
    super.key,
    required this.color,
    this.width = AppSize.s7,
    required this.state,
    this.onDoubleTap,
    this.onSwipe,
    this.onTap,
  });
  final Color color;
  final double width;
  final bool state;
  final Function? onDoubleTap;
  final Function? onSwipe;
  final Function? onTap;
  @override
  Widget build(BuildContext context) {
    double factor = width / AppSize.s7;
    final controller = ValueNotifier<bool>(state);
    return AdvancedSwitch(
      controller: controller,
      // activeColor: Colors.green,
      // inactiveColor: Colors.grey,
      // activeChild: const TextCustom(text:'ON'),
      // inactiveChild: const TextCustom(text:'OFF'),
      // activeImage: const AssetImage('assets/images/on.png'),
      // inactiveImage: const AssetImage('assets/images/off.png'),
      // borderRadius: const BorderRadius.all(Radius.circular(15)),

      enabled: true,
      disabledOpacity: 0.5,
      width: (factor * AppSize.s22).landscapeFontSp(),
      height: (factor * AppSize.s12).landscapeFontSp(),
      activeColor: color,
      inactiveColor: Colors.grey.withOpacity(0.8),
      thumb: Icon(Icons.circle,
          color: AppColor.white, size: width.landscapeFontSp()),
    );
  }
}
