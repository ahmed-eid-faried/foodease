import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/imports/export_path_packages.dart';
import 'package:vendors/core/widgets/custom_scaffold.dart';
import 'package:vendors/core/widgets/layout.dart';
import 'package:vendors/core/widgets/sort/filter_and_sort_app_bar_widget.dart';
import 'package:vendors/core/widgets/text_custom/text_custom.dart';

class SortingSheet extends StatelessWidget {
  const SortingSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: const EdgeInsets.all(0),
      alignment: Alignment.topCenter,
      insetPadding: const EdgeInsets.all(0),
      shape: const RoundedRectangleBorder(),
      backgroundColor: AppColor.white,
      content: Container(
          width: (AppSize.s100 * 3.90).w,
          height: LayoutValue.isLandscape() ? null : (AppSize.s100 * 3.56).h,
          color: AppColor.white,
          child: CustomScaffold(
            body: Column(
              children: [
                const FilterAndSortAppBarWidget(title: LocaleKeys.sortBy),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: AppPadding.p24.w),
                  child: Column(
                    children: [
                      SizedBox(height: AppSize.s18.h),
                      ListView.separated(
                        shrinkWrap: true,
                        itemCount: sortingType.length,
                        separatorBuilder: (BuildContext context, int index) {
                          return Container(
                            width: AppSize.s100 * 3.42,
                            margin:
                                EdgeInsets.symmetric(vertical: AppMargin.m16.h),
                            decoration: shapeDecoration(
                              shape: roundedRectangleBorder(
                                side: const BorderSide(
                                    width: AppSize.s1,
                                    strokeAlign: BorderSide.strokeAlignCenter,
                                    color: AppColor.white2),
                              ),
                            ),
                          );
                        },
                        itemBuilder: (BuildContext context, int index) {
                          return Row(
                            children: [
                              TextCustom(
                                  text: sortigType[index].tr().toTitleCase(),
                                  style: AppFontStyle.black14w400()),
                              const Spacer(),
                              if (index == 0)
                                const SvgPictureCustom(AppSvg.correct),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
