import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/widgets/text_custom/text_custom.dart';

class FilterAndSortAppBarWidget extends StatelessWidget
    implements PreferredSizeWidget {
  const FilterAndSortAppBarWidget({
    super.key,
    required this.title,
  });
  final String title;
  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      text: title,
      iconSvg: AppSvg.cancel,
      actions: [
        TextButton(
            onPressed: () {
              // SelectFilterCubit.get(context).clearFilters();
              // CollectionProductsCubit.get(context).variantFilterValue = [];
              // CollectionProductsCubit.get(context).categoriesId = [];
              // CollectionProductsCubit.get(context).colorFilterValue = [];
              // CollectionProductsCubit.get(context).sizeFilterValue = [];
              // CollectionProductsCubit.get(context).fromPrice = null;
              // CollectionProductsCubit.get(context).toPrice = 0.0;
              // CollectionProductsCubit.get(context).getFiltersCount();
            },
            child: TextCustom(
                text: LocaleKeys.clearAll, style: AppFontStyle.black14w600())),
      ],
      // widget: IconButtonCustom(
      //   onPressed: () {
      //     Go.pop(context);
      //     // Navigator.of(context).pop();
      //   },
      //   iconName: AppSvg.cancel,
      //   // height: AppSize.s12,
      // ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(AppSize.s65);
}
