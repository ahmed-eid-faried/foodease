import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/imports/export_path_packages.dart';
import 'package:vendors/core/widgets/custom_scaffold.dart';
import 'package:vendors/core/widgets/text_custom/text_custom.dart';

class SortReviewsSheet extends StatelessWidget {
  const SortReviewsSheet({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: const EdgeInsets.all(0),
      alignment: Alignment.topCenter,
      insetPadding: const EdgeInsets.all(0),
      shape: const RoundedRectangleBorder(),
      backgroundColor: AppColor.white,
      content: Container(
          width: (AppSize.s100 * 3.90).w,
          height: (AppSize.s100 * 2.3).h,
          color: AppColor.white,
          padding: EdgeInsets.symmetric(horizontal: AppPadding.p24.w),
          child: CustomScaffold(
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: AppSize.s16.h),
                TextCustom(
                  text: 'Sort',
                  style: AppFontStyle.black14w500(),
                ),
                SizedBox(height: AppSize.s18.h),
                ListView.separated(
                  shrinkWrap: true,
                  itemCount: sortReviewsList.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return Container(
                      width: AppSize.s100 * 3.42,
                      margin: EdgeInsets.symmetric(vertical: AppMargin.m16.h),
                      decoration: shapeDecoration(
                        shape: roundedRectangleBorder(
                          side: const BorderSide(
                              width: AppSize.s1,
                              strokeAlign: BorderSide.strokeAlignCenter,
                              color: AppColor.white2),
                        ),
                      ),
                    );
                  },
                  itemBuilder: (BuildContext context, int index) {
                    return Row(
                      children: [
                        TextCustom(
                            text: sortReviewsList[index].tr().toTitleCase(),
                            style: AppFontStyle.black14w400()),
                        const Spacer(),
                        if (index == 0) const SvgPictureCustom(AppSvg.correct),
                      ],
                    );
                  },
                ),
                SizedBox(height: AppSize.s24.h),
                CustomButton(
                  label: "Save",
                  function: () => Go.pop(context),
                )
              ],
            ),
          )),
    );
  }
}
