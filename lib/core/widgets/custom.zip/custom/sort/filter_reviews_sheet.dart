import 'package:vendors/core/imports/export_path.dart';
import 'package:vendors/core/widgets/custom_scaffold.dart';
import 'package:vendors/core/widgets/text_custom/text_custom.dart';

class FilterReviewsSheet extends StatelessWidget {
  const FilterReviewsSheet({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: const EdgeInsets.all(0),
      alignment: Alignment.topCenter,
      insetPadding: const EdgeInsets.all(0),
      shape: const RoundedRectangleBorder(),
      backgroundColor: AppColor.white,
      content: Container(
          width: (AppSize.s100 * 3.90).w,
          height: (AppSize.s100 * 4).h,
          color: AppColor.white,
          padding: EdgeInsets.symmetric(horizontal: AppPadding.p24.w),
          child: CustomScaffold(
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: AppSize.s16.h),
                TextCustom(
                  text: 'Filter',
                  style: AppFontStyle.black14w500(),
                ),
                SizedBox(height: AppSize.s18.h),
                ListView.separated(
                  shrinkWrap: true,
                  itemCount: 5,
                  separatorBuilder: (BuildContext context, int index) {
                    return Container(
                      width: AppSize.s100 * 3.42,
                      margin: EdgeInsets.symmetric(vertical: AppMargin.m16.h),
                      decoration: shapeDecoration(
                        shape: roundedRectangleBorder(
                          side: const BorderSide(
                              width: AppSize.s1,
                              strokeAlign: BorderSide.strokeAlignCenter,
                              color: AppColor.white2),
                        ),
                      ),
                    );
                  },
                  itemBuilder: (BuildContext context, int index) {
                    return Row(
                      children: [
                        TextCustom(
                            text: (index + 1).toString(),
                            style: AppFontStyle.black14w400()),
                        SizedBox(width: AppSize.s8.w),
                        RatingBarCustom(
                            averageRating: (index + 1).toString(),
                            itemCount: 5,
                            showText: false,
                            unratedColor: AppColor.white),
                        const Spacer(),
                        if (index == 0) const SvgPictureCustom(AppSvg.correct),
                      ],
                    );
                  },
                ),
                SizedBox(height: AppSize.s24.h),
                CustomButton(
                  label: "Save",
                  function: () => Go.pop(context),
                )
              ],
            ),
          )),
    );
  }
}
